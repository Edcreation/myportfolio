export { default as Aboutme } from '../components/Aboutme';
export { default as Header } from './Header';
export { default as Cert } from './Cert';
export { default as Contacts } from './Contacts';